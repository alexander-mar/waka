package ghost;

import java.io.File;
import java.io.FileReader;
import processing.core.PApplet;
import org.json.simple.parser.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import ghost.*;


public class gameParser{

    
    
    public gameParser(){
    
    }
    
    public Entity[][] converter(App app){
        
        //read json to get map name
        
        JSONParser parser = new JSONParser();
        String mapfile = "";
        int lives;
        long speed;
        JSONArray modelengths;

        try {
            Object obj = parser.parse(new FileReader("config.json"));
            JSONObject jsonobj = (JSONObject)obj;
            mapfile = (String)jsonobj.get("map");
            lives = Integer.parseInt(String.valueOf(jsonobj.get("lives")));
            speed = (int)jsonobj.get("speed");
            modelengths = (JSONArray)jsonobj.get("modeLengths"); 
            System.out.println(lives);
            System.out.println(speed);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        //can implement some error checking here
        String [] valid= {"0","1","2","3","4","5","6","7","p","g"};

        //reading in the map file
        ArrayList<String> lines = new ArrayList<>();
        try{
            File myobj = new File(mapfile);
            Scanner read = new Scanner(myobj);

            while (read.hasNextLine()){
                lines.add(read.nextLine());
            }
            read.close();

        } catch (FileNotFoundException e){
            e.printStackTrace();
        }

        //setting up 2 dimensional array the size of text file map
        String[] temp = lines.toArray(new String[lines.size()]);
        Entity[][] map = new Entity[temp.length][];


        for (int i = 0; i < temp.length; i+=1){
            map[i] = new Entity[temp[i].length()];
            for (int j = 0; j < temp[i].length(); j+=1){
                
                int adjI = i*16; // the row
                int adjJ = j*16; // the column

                char c = temp[i].charAt(j);

                switch(c){
                    case '0': //empty cell
                        break;
                    case '1':  
                        Obstacle hwall = new Obstacle(adjI, adjJ, app.loadImage("src/main/resources/horizontal.png"));
                        map[i][j] = hwall;
                        break;
                    case '2':
                        Obstacle vwall = new Obstacle(adjI, adjJ, app.loadImage("src/main/resources/vertical.png"));
                        map[i][j] = vwall;
                        break;
                    case '3':
                        Obstacle cWallUL = new Obstacle(adjI, adjJ, app.loadImage("src/main/resources/upLeft.png"));
                        map[i][j] = cWallUL;
                        break;
                    case '4':
                        Obstacle cWallUR = new Obstacle(adjI, adjJ, app.loadImage("src/main/resources/upRight.png"));
                        map[i][j] = cWallUR;
                        break;
                    case '5':
                        Obstacle cWallDL = new Obstacle(adjI, adjJ, app.loadImage("src/main/resources/downLeft.png"));
                        map[i][j] = cWallDL;
                        break;
                    case '6':
                        Obstacle cWallDR = new Obstacle(adjI, adjJ, app.loadImage("src/main/resources/downRight.png"));
                        map[i][j] = cWallDR;
                        break;
                    case '7':
                        Fruit fruit = new Fruit(adjI, adjJ, app.loadImage("src/main/resources/fruit.png"));
                        map[i][j] = fruit;
                        break;
                    case 'p':
                        
                        Waka waka = new Waka(adjI, adjJ, app.loadImage("src/main/resources/playerRight.png"));
                        map[i][j] = waka;
                        app.setlocation(waka);
                        break;
                    case 'g':
                        Ghost ghost = new Ghost(adjI, adjJ, app.loadImage("src/main/resources/ghost.png"));
                        map[i][j] = ghost;
                        break;
                }
            
            }
            
        }
    return map;
        

} 
}
