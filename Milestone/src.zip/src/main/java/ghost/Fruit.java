package ghost;
import processing.core.PImage;

public class Fruit extends Entity {

    public Fruit(int x, int y, PImage sprite){
        super(x, y, sprite);
    }
}