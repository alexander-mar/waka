package ghost;

import processing.core.PApplet;
import processing.core.PImage;
import ghost.gameParser;
import jogamp.graph.font.typecast.tt.engine.Parser;
import ghost.*;

public class App extends PApplet {

    public static final int WIDTH = 448;
    public static final int HEIGHT = 576;

    private gameParser par;
    private Entity[][] map;
    private Waka waka;
    private Ghost ghost;
    private Obstacle obs;

    public App() {
        //Set up your objects
        par = new gameParser();
        
    }

    public void loadImage(){
        //maybe make this method
    }

    public void setup() {
        frameRate(60);
        this.map = par.converter(this); //feed in the app objec
    }

    public void setlocation(Waka w){
        this.waka = w;
    }
    public void keyPressed(){
        waka.logic(key, this); // inp is the key entered for the movement
        waka.move(map, this);
    }

    public void settings() {
        size(WIDTH, HEIGHT);
    }

    public void draw() { 
        //main loop here
        background(0, 0, 0);
        waka.move(map, this);

        for (int i = 0; i < this.map.length; i += 1){
            for (int j = 0; j < this.map[i].length; j += 1){
                
                if (this.map[i][j] != null){
                    this.map[i][j].draw(this);
            }
            }
            
            
        }

        //this.waka.draw(this);;
        
        //while loop to draw the array list
        
    }
    

    public static void main(String[] args) {
        PApplet.main("ghost.App");
    }

}
