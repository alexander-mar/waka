package ghost;
import processing.core.PImage;

public class Waka extends Entity {
    
    public Waka(int x, int y, PImage sprite){
        super(x, y, sprite);
        this.xv = 0;
        this.yv = 0;
        
    }

    Character previouskey;
    Integer xv;
    Integer yv;

    Boolean VerMov;
    
    public void logic(char move, App app){
        //selects the sprite movement design
        //changes and deals w the velocity stuff
        
        if (previouskey == null||move != previouskey){
            previouskey = move;

            //horizontal movement
            if(move == 'w'){
                this.yv = -1;
                VerMov = true;
                this.sprite = app.loadImage("src/main/resources/playerUp.png");
            }
            else if (move == 's'){
                this.yv = 1;
                VerMov = true;
                this.sprite = app.loadImage("src/main/resources/playerDown.png");
            }
            //vertical movement
            else if (move == 'a'){
                this.xv = -1;
                VerMov = false;
                this.sprite = app.loadImage("src/main/resources/playerLeft.png");
            }
            else if (move == 'd'){
                this.xv = 1;
                VerMov = false;
                this.sprite = app.loadImage("src/main/resources/playerRight.png");
            }
        }
        
    }

    public void move(Entity[][] layout, App app){
        //finding location
        int curX = Math.floorDiv(getXc(), 16);
        int curY = Math.floorDiv(getYc(), 16); // CHECK THE +5
        
        if (VerMov == null){
            return;
        }
        //if its vertical movement
        if (VerMov == true){
            //if (layout[curY+yv][curX] == null ||layout[curY+yv][curX] instanceof Fruit ){
            //if (layout[curY][curX+yv] == null ||layout[curY+yv][curX] instanceof Fruit ){    
                this.x += yv; // need to figure out why its the opposite
            //}
            
        }
        //if its horizontal movement
        else{
            //check if anythin in the way
            //if (layout[curY+xv][curX+xv] == null||layout[curY][curX+xv] instanceof Fruit ){
                
                this.y += xv;
            //}
                
               // return;
            }
            //else{
                
              //  return;
            //}
        
        this.setXc(this.x);
        this.setYc(this.y);

        
    }
    public void setGrid(int x, int y){
       
        
    }

}