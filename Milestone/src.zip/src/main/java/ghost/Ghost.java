package ghost;
import processing.core.PImage;

public class Ghost extends Entity {
    
    public Ghost(int x, int y, PImage sprite){
        super(x, y, sprite);
    }

    //refrence to the AI its using and ability to change it
}