package ghost;

public class Level {

    //Store map, pawns list, refrence back to game
    //during composition, we add entities to the board
    //only use pawn list when referring to move it

    //sets pawns initial positions
    //once started, every frame check for end conditions
    //if directional key pressed, move pacman
    //pacman auto moves one square in direction facing
    //every ghost moves one squre, ai chooses

    //resolves interactions between elements
        // ghost waka
        //waka fruit
        //waka board
    //handling player death, reset or game over
    //handling ghost death. reset positoon

}