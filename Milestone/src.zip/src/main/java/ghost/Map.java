package ghost;

public class Map {

    //only concerned with positions of the game objects and layout

    //stores, entities, layout of walls, list of fruits, , refrence to level

    //calc initial position of entities, includin respawn
    
    //moving pawn in certain direction, validates if move is legal

    //raise an event if collision happens, notifies the level

    
}